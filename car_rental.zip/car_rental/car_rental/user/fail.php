<?php 
echo("Payment Failed!");
?>